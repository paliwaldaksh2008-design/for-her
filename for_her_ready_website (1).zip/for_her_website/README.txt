YOUR READY-TO-USE ROMANTIC WEBSITE

PREVIEW IT
1. Extract the ZIP file.
2. Double-click index.html to open it in your browser.
3. To personalise it, open index.html in Notepad and replace the sample letter and card text. Save the file.

PUBLISH IT FREE WITH GITHUB PAGES
1. Go to https://github.com/ and create/sign in to an account.
2. Create a new repository, e.g. little-world-for-you. Choose Public.
3. Upload index.html into the top level of the repository.
4. Open the repository's Settings -> Pages.
5. Under Build and deployment, choose Deploy from a branch. Select branch main and folder /(root), then Save.
6. Wait a minute or two. Return to Settings -> Pages; GitHub will show your live website URL.
7. Open the URL on your phone and test it.

MAKE A QR CODE
1. Copy your live GitHub Pages URL.
2. Visit https://www.qr-code-generator.com/ and create a website/URL QR code.
3. Paste your exact live URL, create the QR, and download/print it.
4. Scan the printed QR with a second phone before gifting it.

IMPORTANT
- This is a static site; it doesn't collect information or send notifications.
- The website URL will be public. Avoid private or sensitive information.
- The QR code must point to the live published URL, not a file on your computer.
